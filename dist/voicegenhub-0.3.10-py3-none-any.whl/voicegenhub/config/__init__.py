"""Simple configuration for VoiceGenHub."""

from .settings import Settings, get_settings

__all__ = [
    "Settings",
    "get_settings",
]