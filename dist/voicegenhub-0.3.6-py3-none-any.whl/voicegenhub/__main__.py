"""Allow VoiceGenHub to be executed as a module with python -m voicegenhub."""

from .cli import main

if __name__ == "__main__":
    main()